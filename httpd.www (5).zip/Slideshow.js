const slideShowSlide = document.querySelector(".slideShow-slide");
const slideShowImg = document.querySelectorAll(".slideShow-slide img");
const slideshowContainer = document.querySelector(".slideshow-container");
let size = slideshowContainer.offsetWidth;

const Slideshow = () => {
  let counter = 0;

  slideShowSlide.style.transform = "translateX(" + -size * counter + "px)";
  slideShowSlide.style.transition = "transform ease-in-out 0.4s";

  window.addEventListener("resize", (e) => {
    slideShowSlide.style.transition = "none";
    size = document.querySelector(".slideshow-container").offsetWidth;
    slideShowSlide.style.transform = "translateX(" + -size * counter + "px)";
    slideShowSlide.style.transition = "transform ease-in-out 0.4s";
  });
  const slideshow = () => {
    counter++;
    if (counter == slideShowImg.length - 1) {
      counter = 0;
    }
    slideShowSlide.style.transform = "translateX(" + -size * counter + "px)";
  };
  console.log("Works");

  setInterval(slideshow, 5000);
};

Slideshow();
